<?php
echo "Restaurant Backend Running!";
?>
